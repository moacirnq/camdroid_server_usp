from flask import jsonify, request, g, abort, url_for, current_app

from datetime import datetime

import unicodedata
from . import api
from .. import rec_man
from .authentication import auth, verify_password
from .errors import forbidden
from ..models import Alert, User, Camera, VideoFile, db


@api.route('/camdroid/get_port/<id>')
@auth.login_required
def get_port(port):
    json = request.json
    user = g.current_user.email
    name = str(json.get('name'))
    link = str(json.get('link'))
    group = str(json.get('group'))
    username = str(json.get('username'))
    password = str(json.get('password'))
    new_cam = Camera(name=name, src=link, username=username, password=password,
                    owner_id=user, group_name=group, group_owner=user)
    db.session.add(new_cam)
    db.session.commit()
    ret =  jsonify({'URL': str(url_for('api.get_camera', id=new_cam.id))})
    print ret
    return ret